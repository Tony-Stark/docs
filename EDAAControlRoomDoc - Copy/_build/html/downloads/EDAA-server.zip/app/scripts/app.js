'use strict';
var urlprefix = "../controlroom/json"; 
//urlprefix = "http://127.0.0.1:8888/controlroom/json"
// function control_constants = {
//   LCD:["ON_OFF","HDMI1","HDMI2","VOL"],
//   PROJECTOR:["ON_OFF"],
//   YES:["ON_OFF","CHANNELS"],
//   HOT:["ON_OFF","CHANNELS"],
//   VC:["ON_OFF"],
//   MIXER:["ON_OFF"]


// } 
function locationObj(name,id,description){
 this.id = id;
 this.name = name;
 this.description = description;
 this.transmiters = [];
 this.recievers = [];
 this.objType = "location";
 this.showType = false;
 this.showIp =  false;
              
 
} 

function tarnsmiterObj(name,id,description,locationId,type,ip,stat,trsnType,transControlType){
 this.name = name;
 this.id = id;
 this.description = description;
 this.locationId = locationId;
 this.type = type;
 this.ip = ip;
 this.stat = stat;
 this.objType = "transmiter";
 this.showType = true;
 this.showIp =  true;
 this.showReceiverType = false;
 this.showTransmiterType = true;
 this.control_type = trsnType;
 this.control_ip = transControlType;
 
 
}
function receiverObj(name,id,description,locationId,type,ip,stat,recvType,recvControlType){
 this.name = name;
 this.id = id;
 this.description = description;
 this.locationId = locationId;
 this.type = type;
 this.ip = ip;
 this.stat = stat;
 this.objType = "receiver";
 this.showType = true;
 this.showIp =  true;
 this.control_type = recvType;
 this.control_ip = recvControlType;
 this.showReceiverType = true;
 this.showTransmiterType = false;

 
}

function getObjectById(arr,id){
    console.log(arr,id);
    for (var i =0; i<arr.length;i++){
      
       if (id == arr[i].id){
         console.log("FOUND ",arr[i],id);
        return arr[i];
      }
    }
  }
function flowObj (tarnsmiterLocationId,receiverId,tarnsmiterId){
  this.tarnsmiterLocationId = tarnsmiterLocationId;
  this.receiverLocationId = "";
  this.receiverId = receiverId;
  this.tarnsmiterId = tarnsmiterId;
  this.objType = "flow";
  this.locations ;
  this.receiver ;
  this.scenario ;

  this.receiver_volume=20;
  this.receiver_input_in="HDMI1";
  this.receiver_start_action=true;
  this.receiver_stop_action=true;


  this.tarnsmiter;
  var _self = this;
  
 
  this.getTarnsmiter = function(){
    if (_self.tarnsmiter!=undefined)
      return _self.tarnsmiter;
    var location = getObjectById(_self.locations,tarnsmiterLocationId);
    if (!location)
      return;
    _self.tarnsmiter = getObjectById(location.transmiters,_self.tarnsmiterId)
     console.log("tarnsmiter",_self.tarnsmiter);
    return _self.tarnsmiter;
  }

  this.getReceiver = function(){
     if (_self.receiver!=undefined)
      return _self.receiver;
    if (_self.scenario.recievers[""+_self.receiverId]){
       
      _self.receiver = _self.scenario.recievers[""+_self.receiverId];
      _self.scenario.recievers[""+_self.receiverId].push(_self);
       console.log("found receiver for flow",_self.scenario.recievers,_self.receiverId);
      return _self.receiver;
    }else{
       var i = _self.scenario.flows.indexOf(_self);
       _self.scenario.flows.splice(i,1);
     }
  }
  this.init = function(){
    _self.getTarnsmiter();
    _self.getReceiver();
  }
}
function scenarioObj(name,id,locationId){
this.id = id;
this.name = name;
this.locationId = locationId;
this.flows = [];
this.recievers = new Object();

this.objType = "scenario";
this.locations ;
var _self = this;
this.location ;

this.init = function(){
   _self.location = getObjectById(_self.locations,_self.locationId);
   if (_self.location == undefined)
    return;
   console.log(" _self.recievers",_self.recievers);
   for (var i = 0 ;i<_self.location.recievers.length;i++){
    _self.recievers[""+_self.location.recievers[i].id] = [];
    _self.recievers[""+_self.location.recievers[i].id].push(_self.location.recievers[i]);
  }
    
}
this.hasFlowFor = function(receiverId){
  return _self.receiverPerFlow[receiverId];
}

}


function handler(type,arr){

  var handle = function(obj) {
 
    if (type=="location")
      {
        var location = new locationObj(obj["name"],obj["ID"],obj["description"]);
       
        arr.push(location);
        return location;
      } else if (type == "transmiter"){
       
        var transmiter = new tarnsmiterObj(
          obj["name"],
          obj["ID"],
          obj["description"],
          obj["LOCATION_ID"],
          obj["SOURCE_TYPE"],
          obj["IP"],
          obj["STATUS"],
          obj["CONTROL_TYPE"],
          obj["CONTROL_IP"]);
        
        arr.push(transmiter);
        return transmiter;
      }else if (type == "receiver"){
       
        var reciever = new receiverObj(
          obj["name"],
          obj["ID"],
          obj["description"],
          obj["LOCATION_ID"],
          obj["SOURCE_TYPE"],
          obj["IP"],
          obj["STATUS"],
          obj["CONTROL_TYPE"],
          obj["CONTROL_IP"]);
        
        arr.push(reciever);
        return reciever;
      }else if (type == "flow"){
        var flow = new flowObj(
          obj["TRASNMITER_LOCATION_ID"],
          obj["RECEIVER_ID"],
          obj["TRASNMITER_ID"]);
        
        arr.push(flow);
        return flow;
      }else if (type == "scenario"){
        var scenario = new scenarioObj(
          obj["name"],
          obj["ID"],
          obj["LOCATION_ID"]);
       
        arr.push(scenario);
        return scenario;
      }
    
    
    }
    return handle;
  
}

function extractDetails(properties,handlerobject){

   
   var obj = new Object();

   // console.log("extractDetails1 ",properties);
   for (var propName in properties) {
    var propObj =  properties[propName];
    
    for (var propObjName in propObj) {
          if (propObjName=="int")
            obj[propObj["string"]] = propObj[propObjName];
          else if (propObjName=="string")
            obj[propObj[propObjName][0]]=propObj[propObjName][1];
        }
       
     
    }
 
   return handlerobject(obj);
   

}


angular.module('ControlRoomApp', [
  'ngCookies',
  'ngResource',
  'ngSanitize',
  'ui.bootstrap',
  'ngDragDrop',
  'ngRoute',
  'ngAnimate','ui.bootstrap',"ui.bootstrap.tooltip","ui.bootstrap.popover", "ui.bootstrap.position"
])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl'
      }).when('/scenarios', {
        templateUrl: 'views/main.html',
        controller: 'ScenariosCtrl'
      }).when('/scenariosControl',{
        templateUrl:'views/controlContainer.html',
        controller:'scenariosControlCtrl',
      }).when('/topologyMap',{
        templateUrl:'views/controlContainer.html',
        controller:'topologyMapCtrl',
      }).when('/login',{
        templateUrl:'views/login.html',
        controller:'loginCtrl',
      }).when('/users',{
        templateUrl: 'views/main.html',
        controller:'usersCtrl',
      }).when('/selectControlRoom',{
        templateUrl:'views/selectControlRoomCtrl.html',
        controller:'selectControlRoomCtrl',
   
      })
      .otherwise({
        redirectTo: '/login'
      })
  }).directive("locationlist",function(){
    return {
      templateUrl:"views/locationlist.html"
    }
  }).directive("locationcontent",function(){
    return {
      templateUrl:"views/locationcontent.html"
    }
  }).directive("userslist",function(){
    return {
      templateUrl:"views/users.html"
    }
  })

  .service('topologyService', function($http, $location,$rootScope) {
    var _self = this;
     this.setTopology = function(data){
          //console.log(data);
          _self.topolgy = data;
        };
   
        this.locations = [];
        this.scenarios = [];
       this.updateObject = function(obj,command,callback)
      {

        var urlpath = urlprefix+"?command="+command+"&json="+JSON.stringify(obj)+"&callback=JSON_CALLBACK";
        console.log(urlpath);
            $http.jsonp(urlpath).
                success(function(data, status) {
                  if (data.res=="NOT_LOGIN")
                    $location.path("login")
                  else if (data.res=="FAIL")
                    callback.error();
                  else
                    callback.ok(data);
                }).
                error(function(data, status) {
                  console.log(data,status);
                    callback.error();
                });


      }
    

    
       
}).service("stateService",function(topologyService){
  var _self = this;
  this.alerts = [];
  this.location = "none";
  this.scenario = "none";
  this.setAlert = function(txt){
    _self.alerts.splice(0,_self.alerts.length);
    _self.alerts.push({msg:txt});

  }
  this.setLocation = function(location1){
     _self.location = location1;
     localStorage.setItem("locationid",location1.id);
  }

  this.setScenario = function(scenario1){
    _self.scenario = scenario1;
  }
  

}).service("repositoryService",function($q,$http,$location,$rootScope,scenariosService){
  var topology = $q.defer();
  this.getTopology = function(){
  $rootScope.allscenarios = []
    
    var urlpath = urlprefix+"?command=gettopology&user="+$rootScope.user+"&callback=JSON_CALLBACK";
    $http.jsonp(urlpath).
                success(function(data, status) {
                 if (data.res=="NOT_LOGIN"){
                    $location.path("login");
                    topology.reject(data);
                    $rootScope.user = undefined;
                }
                var locationsOut = [];
                
                console.log(data.topology.locations[0]);
                var locations = data.topology.locations[0].entry;
				if (data.topology.locations[0].entry.int ){
					locations = [];
					locations.push(data.topology.locations[0].entry);
				}
					
                for (var i=0;i< locations.length;i++ ){
                  console.log(locations[i].location);
                  
                  if (locations[i].location!==undefined){
                      var locationhandler = new handler("location",locationsOut); 
                      var location = extractDetails(locations[i].location.properties[0].entry,locationhandler);
                       
                      var transmiters =  locations[i].location.transmiters[0].entry;
					  
                      if (transmiters!==undefined){
					  if (locations[i].location.transmiters[0].entry.int ){
						transmiters = [];
						transmiters.push(locations[i].location.transmiters[0].entry);
						}
                       for (var j=0;j< transmiters.length;j++ ){
                          var tarnsmitershandler = new handler("transmiter",location.transmiters); 
                          var trasnmiter = extractDetails(transmiters[j].transmiter.properties[0].entry,tarnsmitershandler);
                      }
                    }
                    var recievers =  locations[i].location.recievers[0].entry;
					
                      if (recievers!==undefined){
					  if (locations[i].location.recievers[0].entry.int ){
						recievers = [];
						recievers.push(locations[i].location.recievers[0].entry);
					}
                       for (var j=0;j< recievers.length;j++ ){
                          var receivershandler = new handler("receiver",location.recievers); 
                          var reciever = extractDetails(recievers[j].reciever.properties[0].entry,receivershandler);
                      }
                    }
                }
                

                }
              console.log("repositoryService",locationsOut);
              $rootScope.locations = locationsOut
               topology.resolve(locationsOut);
              //$rootScope.allscenarios.splice(0, $rootScope.allscenarios.length)
             

        }).
        error(function(data, status) {
          topology.reject(data);
             
      });
      return topology.promise;
}

}
).service("scenariosService",function($q,$http,topologyService){
  
  this.getScenarios = function(topology){
    var scenariosOut = $q.defer();
    var scenarios = [];
       console.log("start loadScenarios....");
          var urlpath = urlprefix+"?command=getscenarios&callback=JSON_CALLBACK";
            scenarios.splice(0,scenarios.length);
           

             $http.jsonp(urlpath).
                success(function(data, status) {
                  console.log("scenarios loaded",data);

                var tempScenarios = data.list[0].scenario;
                if (data.list[0].scenario.properties){
                   data.list[0].scenario = [data.list[0].scenario]

                }

                //console.log(data.list[0].scenario);
                for (var i=0;i< data.list[0].scenario.length;i++ ){
            
                 // console.log(data.list[0].scenario[i]);
                  var scenariohandler = new handler("scenario",scenarios); 
                  var scenario = extractDetails(data.list[0].scenario[i].properties[0].entry,scenariohandler);
                  scenario.locations = topology;
                  scenario.init();
                 if (data.list[0].scenario[i].flows[0].entry != undefined){
                  if (!data.list[0].scenario[i].flows[0].entry.length)
                    data.list[0].scenario[i].flows[0].entry = [data.list[0].scenario[i].flows[0].entry];
                  for (var j=0;j<  data.list[0].scenario[i].flows[0].entry.length;j++ ){
                    
                      var flowhandler = new handler("flow",scenario.flows); 
                      var flow = extractDetails(data.list[0].scenario[i].flows[0].entry[j].flow.properties[0].entry,flowhandler);
                      flow.receiverLocationId = scenario.locationId;
                      flow.locations = topology;
                      flow.scenario = scenario;
                      flow.init();
                 }
               }
                console.log("after init",scenario);
                
                }
                scenariosOut.resolve(scenarios);
               
                }).error(function(data, status) {
                   console.log("error loading scenarios",data);
                    
              });
              return scenariosOut.promise;
    }

}).service("userService",function($q,$http,$location,topologyService){
  this.getUsers = function(){
     var usersOut = $q.defer();
    var users = [];
       console.log("start getUsers....");
          var urlpath = urlprefix+"?command=getusers&callback=JSON_CALLBACK";
           
           

            $http.jsonp(urlpath).
                success(function(data, status) {
                  console.log(data['string-array'][0]['string'])
                  if (data.res=="NOT_LOGIN")
                    $location.path("login")
                  else{
                    var jsonusers = data['string-array'][0]['string'];
                    for (var i=0;i<jsonusers.length;i++)
                    {
                      users.push(jsonusers[i].split("="))
                      console.log(users)
                    }

                    usersOut.resolve(users)
                  }
                 
                }).
                error(function(data, status) {
                  console.log(data,status);
                  // $location.path("login")
                });
              return usersOut.promise;
    }

  });

