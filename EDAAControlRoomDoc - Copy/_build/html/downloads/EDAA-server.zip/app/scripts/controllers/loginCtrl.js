function loginCtrl($route,$rootScope,$scope,$location,$cookieStore,topologyService,stateService){
	$scope.login = function(){
		var user = new Object();
    if ($scope.email== undefined)
      $scope.email = $("#login").val();
    if ($scope.password== undefined)
      $scope.password = $("#password").val();

		user.email = $scope.email;
		user.password = $scope.password;

		topologyService.updateObject(user,"login",new function(){
                this.ok = function(data){

                  console.log(data,"login ",user);
                  if (data.res=="VALID"){
                  	
                    $rootScope.user = user.email;
                    $rootScope.showInvalidSystem = data.showInvalidSystem;
                    $cookieStore.put("user",user.email)
                     $cookieStore.put("userType",data.type)
                    console.log("login",data.type)
                       if (data.type=="control"){
                       
                        $rootScope.filterlocationas= data.filter
                        $location.path("/selectControlRoom");

                       }
                       else
                         $location.path("");


                  }else{
                  	 stateService.setAlert("שם המשתמש או הסיסמה לא תקין");
                  }
                
                 
            };
            this.error = function(){
                  stateService.setAlert("בעיה בתקשורת, בדוק חיבור לשרת");
                 $cookieStore.remove("user");
                 $cookieStore.remove("userType");
                   

                };
         });     
	};
	$scope.okFunc = function(result,status,xhr){
		console.log(xhr);
		alert('סיסמה נשלחה בדואר');
	}
	$scope.errorFunc = function(xhr,status,error){
		console.log(xhr);
		if (xhr.status == 200){
			alert('סיסמה נשלחה בדואר');
			$('#restore_password_modal').modal('hide');
		}
		else
			alert('בעיה בשליחת הודעה'+" status "+status+" error "+error);
	}
	$scope.showRestorePassword = function(){
		$('#restore_password_modal').modal('show');
	};
	$scope.forgotPassword = function(){
		//console.log("hi",jQuery("#login").val());
			if (!jQuery("#restore_password_modal input").val() || jQuery("#restore_password_modal input").val()==="")
				alert("יש צורך למלא את הEMAIL");
			else{
				
				var urlpath = urlprefix+"?command=password&user="+jQuery("#restore_password_modal input").val();
				jQuery.ajax({
					  url: urlpath,
					 
					  error: $scope.errorFunc,
					  success: $scope.okFunc,
					 
					});

			}

	};
  

}