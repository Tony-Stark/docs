'use strict';

angular.module('ControlRoomApp')
  .controller('MainCtrl', function ($rootScope,$scope,$modal,$cookieStore,$log,$location,topologyService,stateService,repositoryService) {


     $rootScope.user = $cookieStore.get("user");
     var u_type = $cookieStore.get("userType");
     if (u_type=="control" && $rootScope.user)
         $location.path("/selectControlRoom");  

    $rootScope.logoutUser = function(){
    topologyService.updateObject("","logout",new function(){
      this.ok= function(data){
        $rootScope.user = null
         $cookieStore.remove("user");
         $cookieStore.remove("userType");
         window.location.reload(false); 
      }
      this.error= function(data){
         $rootScope.user = null
       window.location.reload(false); 
      }
    })
  }
  $scope.filter = "";
  $scope.isFilterout = function(obj){
    console.log("filter",obj,$scope.filter);
    if ($scope.filter == "")
      return false;
    return obj.name.indexOf($scope.filter) !== -1
  }
   $scope.contenturl = "views/locationcontent.html"
 
     console.log("before init...");
	   // topologyService.init(callback);
    
    repositoryService.getTopology().then(function(topology){
         console.log("repositoryService.getTopology()",topology);
         $scope.locations =   topology;
         var locid = localStorage.getItem("locationid");
         for (var i=0;i<$scope.locations.length;i++){
          if (locid==$scope.locations[i].id)
            $scope.setLocation($scope.locations[i]);

         }
         locid = localStorage.getItem("locationid"); 
         if (locid==""){
           $scope.setLocation($scope.locations[0]);
         }
       stateService.setAlert("הטופולוגיה נטענה"+topology.length);
     
     },function(reason){
       console.log("repositoryService.getTopology()",reason);

     },null);


	$scope.setLocation = function(location){
		stateService.setLocation(location);
		$scope.recievers = location.recievers;
		$scope.transmiters = location.transmiters;
    $scope.locationid = location.id;
	}

 
 $scope.deleteCurrentLocation = function(){
  console.log("deleteCurrentLocation",stateService);
  $scope.delete(stateService.location);
 }
 $scope.isActiveView = function(path){
    
  return path == "topology"
    
 }
	$scope.isActive = function(location){
		return location.id == stateService.location.id;
  	}

  $scope.showUploadControlFile = function(){
    $('#uploadControlFiles').modal('show');
  }
   $scope.showDownloadFile = function(){
    //$scope.delete(stateService.location);
    //$('#uploadControlFiles').modal('show');
    window.open($location.path+"/../downloadcsv?id="+stateService.location.id); 

    window.location.assign('url');
  }
   
  $scope.createNewObject = function(newObjectLocationType){

    console.log(newObjectLocationType)
    var obj = new Object();
    obj["ip"]="1.1.1.1";
    obj["description"] = "";
    obj["name"]="";
    obj["locationId"] = ("location" == newObjectLocationType ? "-1" : stateService.location.id);
    obj["objType"] = newObjectLocationType;
    obj["showType"] =  newObjectLocationType!="location";
    obj["showIp"] =  newObjectLocationType!="location";
    
    if ( newObjectLocationType=="receiver"){
      obj["receiver_type"] = "LCD"; 
      obj["receiver_control_ip"] = "1.1.1.1";
      obj["showReceiverType"] = true;
      obj["showTransmiterType"] = false;



    }else if ( newObjectLocationType=="transmiter"){
      
     
      obj["showReceiverType"] = false;
      obj["showTransmiterType"] = true;
      obj["transmiter_type"] = "DEFAULT";
     



    }

     var okFuncEdit = function () {
              topologyService.updateObject(obj,"updateNew",new function(){
                this.ok = function(data){

                  console.log(data,"update item ",obj);

           if ("location" == newObjectLocationType){
           var newObj =new locationObj(
                      obj['name'],
                      data['id'],
                      obj['description']
                      )
					 if (!$scope.locations)
						$scope.locations = []
                  $scope.locations.push(newObj);
          }
          else if ("transmiter" == newObjectLocationType){
            var newObj =new tarnsmiterObj(
                      obj['name'],
                      data['id'],
                      obj['description'],
                      obj['locationId'],
                      obj['type'],
                      obj['ip'])
				if (!stateService.location.transmiters)
					stateService.location.transmiters = [];
                  stateService.location.transmiters.push(newObj);
          }
          else if ("receiver" == newObjectLocationType){
            var newObj =new receiverObj(
                      obj['name'],
                      data['id'],
                      obj['description'],
                      obj['locationId'],
                      obj['type'],
                      obj['ip'])
					  
				if (!stateService.location.recievers)
					stateService.location.recievers = [];
                  stateService.location.recievers.push(newObj);
          }
                  
                  //$scope.recievers.push(newRcvObj);
                  stateService.setAlert("העידכון הצליח ");

                }
                 this.error = function(){
                  console.log("Fail to update",obj);
                 
                   stateService.setAlert("העדכון נכשל, נא בדוק חיבור לשרת");

                }
              });
              for (var k=0;k<$rootScope.locations.length;k++){
                if ($rootScope.locations[k].id==stateService.location.id){
                  $rootScope.locations[k]=stateService.location;
                }
              }

            };
    var modalInstance  = $modal.open({
      templateUrl: 'views/modalEdit.html',
      controller: ModalInstanceCtrl,
     
      resolve: {
          header: function(){
        return "צור חדש";
      },
        item: function () {
         return obj;
        },
        type: function () {
          return "delete";
        },
        okButtonTitle: function () {
          return "שמור";
        },okFunction: function(){
          return okFuncEdit
        }
      }
    });
    modalInstance.result.then(function (selectedItem) {
        //$scope.selected = selectedItem;
      }, function () {
        $log.info('Modal dismissed at: ' + new Date());
      });
  }

	$scope.edit = function(obj){
     var okFuncEdit = function () {
             
              
              topologyService.updateObject(obj,"updateNew",new function(){
                this.ok = function(data){

                  console.log(data,"update item ",obj);

                  
                  stateService.setAlert("העידכון הצליח ");

                }
                 this.error = function(){
                  console.log("Fail to update",obj);
                 
                   stateService.setAlert("העדכון נכשל, נא בדוק חיבור לשרת");

                }
              });

            };
		var modalInstance  = $modal.open({
      templateUrl: 'views/modalEdit.html',
      controller: ModalInstanceCtrl,
     
      resolve: {
      		header: function(){
      	return "ערוך";
      },
        item: function () {
         return obj;
        },
        type: function () {
          return "delete";
        },
        okButtonTitle: function () {
          return "שמור";
        },okFunction: function(){
          return okFuncEdit
        }
      }
    });
		modalInstance.result.then(function (selectedItem) {
	      //$scope.selected = selectedItem;
	    }, function () {
	      $log.info('Modal dismissed at: ' + new Date());
	    });
	}
 
	$scope.delete = function(obj){
     var okFuncDelete = function () {
             
              
              topologyService.updateObject(obj,"delete",new function(){
                this.ok = function(data){

                  console.log(data,"delete item ",obj);
                   if ("location" == obj["objType"]){
                      for (var i=0;i<$scope.locations.length;i++){
                        if ($scope.locations[i].id == data.id){
                        $scope.locations.splice(i,1);
                        $scope.setLocation($scope.locations[0]);
                        break;
                      }
                    }
                  }
                  if ("transmiter" == obj["objType"]){
                      for (var i=0;i<stateService.location.transmiters.length;i++){
                        if (stateService.location.transmiters[i].id == data.id)
                        stateService.location.transmiters.splice(i,1);
                    }
                  }
                   if ("receiver" == obj["objType"]){
                      for (var i=0;i<stateService.location.recievers.length;i++){
                        if (stateService.location.recievers[i].id == data.id){
                        stateService.location.recievers.splice(i,1);
                        console.log("removed",data.id);
                      }
                    }
                  }
          
                  stateService.setAlert("העידכון הצליח ");

                }
                 this.error = function(){
                  console.log("Fail to update",obj);
                 
                   stateService.setAlert("העדכון נכשל, נא בדוק חיבור לשרת");

                }
              });

            }
		var modalInstance  = $modal.open({
      templateUrl: 'views/modalDelete.html',
      controller: ModalInstanceCtrl,
      
      resolve: {
      	header: function(){
      	return "מחק";
      },
        item: function () {
          return obj;
        },
        type: function () {
          return "delete";
        },
        okButtonTitle: function () {
          return "מחק";
        },okFunction:function(){
          return okFuncDelete;
      }
    }
  });
		modalInstance.result.then(function (selectedItem) {
	      
	    }, function () {
	      $log.info('Modal dismissed at: ' + new Date());
	    });
	}
  });


 var ModalInstanceCtrl = function ($scope, $modalInstance,topologyService,header,item,type,okButtonTitle,okFunction) {
  $scope.okButtonTitle = okButtonTitle;
 	$scope.item = item;
  $scope.modalOptions = {
            closeButtonText: 'Close',
            actionButtonText: 'OK',
            headerText: header+" "+item.name,
            
        };

  // $scope.items = items;
  $scope.selected = {
    //item: $scope.items[0]
  };


  $scope.ok = function () {
   $modalInstance.dismiss('cancel');
   okFunction();
  };

  $scope.cancel = function () {
   $modalInstance.dismiss('cancel');
  };
};

function AlertDemoCtrl($scope,stateService) {
  $scope.alerts = stateService.alerts;

  $scope.addAlert = function() {
    $scope.alerts.push({msg: "Another alert!"});
  };

  $scope.closeAlert = function(index) {
    $scope.alerts.splice(index, 1);
  };

}

function DropdownCtrl($scope) {
  $scope.items = [
    "The first choice!",
    "And another choice for you.",
    "but wait! A third!"
  ];
}

function setSkrollr(){
    var objDistance = $navbar.offset().top;
    $(window).scroll(function() {
        var myDistance = $(window).scrollTop();
        if (myDistance > objDistance){
            $navbar.addClass('navbar-fixed-top');
        }
        if (objDistance > myDistance){
            $navbar.removeClass('navbar-fixed-top');
        }
    });
}
