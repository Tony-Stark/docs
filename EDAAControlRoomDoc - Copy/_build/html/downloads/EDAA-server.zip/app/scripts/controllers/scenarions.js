function ScenariosCtrl ($scope,$modal,$rootScope,$location,$log,topologyService,stateService,repositoryService,scenariosService) {

$scope.contenturl = "views/scenarios.html"
$scope.scenarios = [];
$scope.allscenarios = [];
$scope.tarnsmiterlocation;
$scope.selectedscenarion ;
 
 var emptyScenario = new scenarioObj();
 emptyScenario.name="emptyScenario";

$scope.openEditTargetDialog = function(reciever,scenario,flow){

  // console.log(reciever,scenario,flow)
  // console.log("radio button",$('input[name=receiver_input_in]').filter('[value=\"'+flow.receiver_input_in+'\"]'));

$('#flow_header').text(reciever.name);

$('#receiver_volume').val(flow.receiver_volume);
$('input[name=receiver_input_in]').filter('[value=\"'+flow.receiver_input_in+'\"]').attr('checked', true);
$('#receiver_start_action').attr('checked', flow.receiver_start_action);
$('#receiver_stop_action').attr('checked',flow.receiver_stop_action);


$('#editTargetModal').modal('show');
};
 $scope.filterOutScenarios = function(){
if (!$rootScope.allscenarios)
  return

 	$scope.scenarios.splice(0,$scope.scenarios.length);
 	 for (var i = 0 ;i < $rootScope.allscenarios.length;i++){
  	if ($rootScope.allscenarios[i].locationId == stateService.location.id){
  		$scope.scenarios.push($rootScope.allscenarios[i])

  	}

  
 }
 console.log("filterOutScenarios",$scope.scenarios);
 if ($scope.scenarios.length > 0 )
   $scope.setActiveScenario(0);
     
   else
    console.log("setActiveScenario fail");


}
$scope.hideSelectedScenario = function(){
  console.log("document.getElementById('activescenario').options[0].value==?",document.getElementById("activescenario").options[0].value=="?");
  return document.getElementById("activescenario").options[0].value=="?";

}
	$scope.setLocation = function(location){

    console.log($rootScope);
		$scope.scenarios.splice(0,$scope.scenarios.length);
    for (var i = 0 ;i < $rootScope.allscenarios.length;i++){
    if ($rootScope.allscenarios[i].locationId == location.id)
      $scope.scenarios.push($rootScope.allscenarios[i])
    }

    $scope.selectedscenarion = $scope.scenarios[0];
    console.log("setLocation",location," $scope.selectedscenarion", $scope.selectedscenarion);
		stateService.setLocation(location);


		$scope.recievers = location.recievers;
		$scope.transmiters = location.transmiters;
    $scope.locationid = location.id;
    	//$scope.filterOutScenarios();
    }

	$scope.setActiveScenario = function(indexScenario){
  
	 $scope.selectedscenarion = $scope.scenarios[indexScenario];

  console.log("setActiveScenario", $scope.selectedscenarion);
	}
	$scope.isActive = function(location){
		return location.id == stateService.location.id;
  	}
	$scope.isActiveScenario = function(scenario){
		return scenario.id == selectedscenarion.id;
  	}
  	 $scope.isActiveView = function(path){
  		
  		return path == "scenarios"
 	}
  console.log("select first scenario...");
 	 $scope.filterOutScenarios();
 	 if ($scope.scenarios.length > 0 )
 	   $scope.setActiveScenario(0);

	$scope.dropSuccessHandler = function($event,index,data,selectedscenarion){
    var flow = new flowObj(index.locationId,data.id,index.id);
    console.log("dropSuccessHandler data",data);
    flow.scenarioId = selectedscenarion.id;
    topologyService.updateObject(flow,"addFlow",new function(){
                this.ok = function(datain){

                   console.log("dropSuccessHandler",index,$event,data);
                    
                  flow.locations = $scope.locations;
         

                  console.log("newFlow",selectedscenarion.recievers[""+data.id]);
                  flow.scenario = selectedscenarion;
                  flow.init();

                  for (var i=0;i<selectedscenarion.flows.length;i++){
                    if (selectedscenarion.flows[i].receiverId == flow.receiverId)
                    {
                      selectedscenarion.flows.splice(i,1);
                      break;
                    }
                  }
                 selectedscenarion.flows.push(flow);
                 selectedscenarion.recievers[""+data.id].splice(1,selectedscenarion.recievers[""+data.id].length);
                  selectedscenarion.recievers[""+data.id][1]=flow;
                  stateService.setAlert("העידכון הצליח ");
            }
            this.error = function(){
                  console.log("Fail to update",flow);
                 
                   stateService.setAlert("העדכון נכשל, נא בדוק חיבור לשרת");

                }
         });    
         
      };
      
      $scope.onDrop = function($event,$data){
           console.log("onDrop",$event,$data);
      };

 $scope.createScenario= function(){

    var obj = new Object();
     obj["description"] = "";
    obj["name"]="";
    obj["locationId"] = stateService.location.id;
    obj["objType"] = "scenario";
     var okFuncEdit = function () {
              topologyService.updateObject(obj,"updateNewScenario",new function(){
                this.ok = function(data){

                  console.log(data,"new scenario ",obj);
                  var newObj =new scenarioObj(
                      obj['name'],
                      data['id'],
                      stateService.location.id
                      );

                  newObj.locations = $scope.locations;
                  newObj.init();

                  $scope.allscenarios.push(newObj);
                  console.log("after push",$scope.allscenarios);
                  $scope.filterOutScenarios();
                 
                
                  stateService.setAlert("העידכון הצליח ");
                  window.location="#";
                  setTimeout(function(){window.location="#scenarios"},200);
            }
            this.error = function(){
                  console.log("Fail to update",obj);
                 
                   stateService.setAlert("העדכון נכשל, נא בדוק חיבור לשרת");

                }
         });     
    }
            
    var modalInstance  = $modal.open({
      templateUrl: 'views/modalEdit.html',
      controller: ModalInstanceCtrl,
     
      resolve: {
          header: function(){
        return "צור חדש";
      },
        item: function () {
         return obj;
        },
        type: function () {
          return "delete";
        },
        okButtonTitle: function () {
          return "שמור";
        },okFunction: function(){
          return okFuncEdit
        }
      }

    });
        modalInstance.result.then(function (selectedItem) {
    }, function () {
        $log.info('Modal dismissed at: ' + new Date());
      });
  }

 $scope.deleteFlow = function(reciever,scenario,flowin){
  console.log("delete flow",reciever,scenario,flowin);

   var flow = new Object();
   flow.scenarioId = scenario.id;
   flow.receiverId = reciever.id;
   

    topologyService.updateObject(flow,"deleteFlow",new function(){
                this.ok = function(datain){

                   console.log("deleteFlow",scenario.recievers[flow.receiverId]);
                   scenario.recievers[flow.receiverId].splice(1,1);
                  
            
                  
            }
            this.error = function(){
                  console.log("Fail to update",flow);
                 
                   stateService.setAlert("העדכון נכשל, נא בדוק חיבור לשרת");

                }
         });    
         
 }

 $scope.deleteScenario= function(selectedscenarion){
console.log("delete ",selectedscenarion);
   var obj = new Object();
     obj["description"] = "";
    obj["name"]="";
    obj["id"] = selectedscenarion.id;
    obj["locationId"] = stateService.location.id;
    obj["objType"] = "scenario";
     var okFuncEdit = function () {
              topologyService.updateObject(obj,"deleteScenario",new function(){
                this.ok = function(data){

                  console.log(data,"delete scenario ",obj);
                  var i =  $scope.allscenarios.indexOf(selectedscenarion);

                  $scope.allscenarios.splice(i,1);
                  $scope.filterOutScenarios();

                  window.location="#";
                  setTimeout(function(){window.location="#scenarios"},200);
                  stateService.setAlert("העידכון הצליח ");

            }
            this.error = function(){
                  console.log("Fail to update",selectedscenarion);
                 
                   stateService.setAlert("העדכון נכשל, נא בדוק חיבור לשרת");

                }
         });     
}
            
    var modalInstance  = $modal.open({
      templateUrl: 'views/modalDelete.html',
      controller: ModalInstanceCtrl,
     
      resolve: {
          header: function(){
        return "מחק";
      },
        item: function () {
         return selectedscenarion;
        },
        type: function () {
          return "delete";
        },
        okButtonTitle: function () {
          return "מחק";
        },okFunction: function(){
          return okFuncEdit
        }
      }

});
        modalInstance.result.then(function (selectedItem) {
        //$scope.selected = selectedItem;
      }, function () {
        $log.info('Modal dismissed at: ' + new Date());
      });
  }
    
$log.info("init scenarios...",$rootScope.allscenarios,$rootScope.locations)
if ($rootScope.allscenarios  ){

// //$scope.selectedscenarion = emptyScenario  ;
// repositoryService.getTopology().then(
//   function(topology){
//     $scope.locations =  topology;
    var locid = localStorage.getItem("locationid");
    if (locid=="")
      locid = $rootScope.locations[0].id;
    scenariosService.getScenarios($rootScope.locations).then(
      function(scenarios1){
       $rootScope.allscenarios = scenarios1;  
        $scope.scenarios.splice(0,$scope.scenarios.length);
         for (var i = 0 ;i < $rootScope.allscenarios.length;i++){
          console.log("$scope.allscenarios[i]",$scope.allscenarios[i])
           if ($rootScope.allscenarios[i].locationId == locid)
            $scope.scenarios.push($rootScope.allscenarios[i])

          }
    },
    function(error){},null)

//   },
//   function(rejected){},null);


}
else{
  window.location = "#"
}
// $scope.filterOutScenarios();

}