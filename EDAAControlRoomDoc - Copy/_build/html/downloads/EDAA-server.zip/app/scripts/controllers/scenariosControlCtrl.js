function scenariosControlCtrl ($timeout,$scope,$rootScope,$modal,$location,$log,stateService,repositoryService,scenariosService,topologyService) {

if ($rootScope.user == null)
  $location.path("/")
console.log("start loading scenarios",$location);
$scope.scenarios = new Object();
$scope.allscenarios = [];
$scope.contenturl="views/scenariosControl.html";
$scope.isActiveView = function(page){
    return page=='scenariosCtrl'
  }
$scope.getStatus = function(){
	console.log("in getStatus");
	$timeout($scope.getStatus,5000);
	var obj = new Object();
	var str = "";
	
  for(var id in $scope.scenarios) {
    str+=id;
    str+=",";
  }
	obj["scenarios"]=str;
	topologyService.updateObject(obj,"scenariosStatus",new function(){
                this.ok = function(data){

                   for(var id in $scope.scenarios) {
                    $scope.scenarios[id]['status'] = 'hold';
                    
                  }
                  if (data['scenarioStatus-array'][0].scenarioStatus){
                    if (data['scenarioStatus-array'][0].scenarioStatus.length){
                        

                         for (var i=0;i<data['scenarioStatus-array'][0].scenarioStatus.length;i++){
                        
                        var scenarioStatus = data['scenarioStatus-array'][0].scenarioStatus[i];
                         $scope.scenarios[scenarioStatus.scenarioId]['status'] = 'running';
                        
                      }
                    }else {
                       $scope.scenarios[data['scenarioStatus-array'][0].scenarioStatus.scenarioId]['status'] = 'running';
                  }
                  }

                  stateService.setAlert("טוען מצב תרחישים");
            }
            this.error = function(){
                  console.log("Fail to update",obj);
                 
                   stateService.setAlert("נכשלה טעינת התרחישים, בדוק שרת..");

                }
         });     
}

$scope.startPulling = function(){
	$timeout($scope.getStatus, 10);
}
if (!$rootScope.locations)
repositoryService.getTopology().then(
  function(topology){
    $scope.locations =  topology;
    $rootScope.locations = topology
    scenariosService.getScenarios(topology).then(
      function(scenarios1){
          for (var i=0;i<scenarios1.length;i++)
            $scope.allscenarios.push(scenarios1[i]);
       
        $scope.filterOutScenarios($rootScope.controlroomLocationId);
        $scope.startPulling();
    },
    function(error){},null)

  },
  function(rejected){},null);
 else
 scenariosService.getScenarios($rootScope.locations).then(
      function(scenarios1){
        console.log(scenarios1)
          for (var i=0;i<scenarios1.length;i++){
            $scope.allscenarios.push(scenarios1[i]);

        }
        $rootScope.allscenarios = $scope.allscenarios;
        $scope.filterOutScenarios($rootScope.controlroomLocationId);
        $scope.startPulling();
    },
    function(error){},null)

 $scope.filterOutScenarios = function(locationId){

 if (!locationId)
  console.error("no locationId found",$rootScope.allscenarios)
else
  console.error("locationId",locationId,$rootScope.allscenarios)
  for(var id in $scope.scenarios) {
     delete $scope.scenarios[id];
  }
 	 for (var i = 0 ;i < $scope.allscenarios.length;i++){
  	if ($scope.allscenarios[i].locationId == locationId){
  		$scope.scenarios[""+$scope.allscenarios[i].id]=$scope.allscenarios[i];
      $scope.scenarios[""+$scope.allscenarios[i].id]['status'] = 'hold';

  	}

  
 }
}

 $scope.startScenario = function(scenario){
	console.log("delete ",scenario);
   var obj = new Object();
    obj["id"] = scenario.id;
    obj["objType"] = "scenario";
     var okFuncEdit = function () {
              topologyService.updateObject(obj,"startScenario",new function(){
                this.ok = function(data){

                  

                  stateService.setAlert("תרחיש התחיל... ");
            }
            this.error = function(){
                  console.log("Fail to update",scenario);
                 	
                   stateService.setAlert("התרחיש לא התחיל");

                }
         });     
	}
            
    var modalInstance  = $modal.open({
      templateUrl: 'views/modalDelete.html',
      controller: ModalInstanceCtrl,
     
      resolve: {
          header: function(){
        return "התחל תרחיש";
      },
        item: function () {
         return scenario;
        },
        type: function () {
          return "start";
        },
        okButtonTitle: function () {
          return "התחל תרחיש";
        },okFunction: function(){
          return okFuncEdit
        }
      }

});
        modalInstance.result.then(function (selectedItem) {
        
      }, function () {
        $log.info('Modal dismissed at: ' + new Date());
      });
  }
  

$scope.stopScenario = function(scenario){
	console.log("delete ",scenario);
   var obj = new Object();
    obj["id"] = scenario.id;
    obj["objType"] = "scenario";
     var okFuncEdit = function () {
              topologyService.updateObject(obj,"stopScenario",new function(){
                this.ok = function(data){

                  

                  stateService.setAlert("תרחיש הפיק... ");
            }
            this.error = function(){
                  console.log("Fail to update",scenario);
                 
                   stateService.setAlert("עצירת התרחיש נכשלה");

                }
         });     
}
            
    var modalInstance  = $modal.open({
      templateUrl: 'views/modalDelete.html',
      controller: ModalInstanceCtrl,
     
      resolve: {
          header: function(){
        return "הפסק תרחיש";
      },
        item: function () {
         return scenario;
        },
        type: function () {
          return "start";
        },
        okButtonTitle: function () {
          return "הפסק תרחיש";
        },okFunction: function(){
          return okFuncEdit
        }
      }

});
        modalInstance.result.then(function (selectedItem) {
        
      }, function () {
        $log.info('Modal dismissed at: ' + new Date());
      });

}

}