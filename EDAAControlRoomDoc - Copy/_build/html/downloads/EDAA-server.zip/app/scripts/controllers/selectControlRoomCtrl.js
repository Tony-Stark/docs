function selectControlRoomCtrl($route,$rootScope,$scope,$location,$cookieStore,topologyService,repositoryService,stateService){

if ($rootScope.user == null)
  $location.path("/")
 
 

  repositoryService.getTopology().then(function(topology){
         console.log("repositoryService.getTopology()",topology);
         $rootScope.locations =   topology;
         $scope.locations = topology
         console.log( "$scope.locations", $scope.locations)

      
       stateService.setAlert("הטופולוגיה נטענה"+topology.length);
     
     },function(reason){
       console.log("repositoryService.getTopology()",reason);

     },function(data){
      console.log("finally",data)
     });
   
   if ($rootScope.locations)
      $scope.locations = $rootScope.locations;


   $rootScope.logoutUser = function(){
    topologyService.updateObject("","logout",new function(){
      this.ok= function(data){
        $rootScope.user = undefined 
         
         $cookieStore.remove("user");
          window.location.reload(false); 
      }
      this.error= function(data){
         $rootScope.user = null
         
         window.location.reload(false); 
      }
    })
  }
  
  
	$scope.setLocation = function(locationId){
    $rootScope.controlroomLocationId = locationId;
    $location.path("/topologyMap");
	}

  

}