
function topologyMapCtrl ($scope,$modal,$location,$log,$rootScope,$timeout,topologyService,stateService,repositoryService,scenariosService) {
	if ($rootScope.user == null)
  		$location.path("/")

	$scope.locationId = $rootScope.controlroomLocationId;
	$('#remoteControl').modal('hide');
 	$('#remoteControl').bind('hide', function () {
   		$('#calculator').css('display','none');
   		$('#calculator').removeClass();
 	});
	$scope.mapUrl="views/topologyMap_"+$scope.locationId+".html";
	$scope.image = "images/location_"+$scope.locationId+".jpg";

	$scope.contenturl="views/topologyMap.html";
	$scope.flowStatus =  new Object();
	$scope.flowStatusPositions = new Object();
	$scope.flowStatus.recievers = new Object();

	

	$scope.isActiveView = function(page){
		return page=='topologyMapCtrl'
	}
	$scope.flowStatus.init = function(){

		
		 console.log("init ",$scope.currentLocation );

		 for (var i=0;i<$scope.currentLocation .recievers.length;i++){
		 	var reciever = $scope.currentLocation .recievers[i];
		 	var el = angular.element("<div>");
		 	

		 	var idOfCoords = "#area_"+reciever.id;
		 	var target = angular.element(idOfCoords);
		 	
				console.log(idOfCoords,target);
				var coords = target.prop("coords");
				var leftExtra = target.attr("left-extra");
				var topExtra = target.attr("top-extra");
				if (coords){
				coords = coords.split(',')
				
				
				var style = "position:absolute;min-width:100px;border:1px solid #ADD8E6;background-color:#FFFFFF;";
				style +="left:"+(parseInt(coords[2])+Number(leftExtra))+"px;";
				style += "top:"+(parseInt(coords[3])+Number(topExtra))+"px";
				$scope.flowStatusPositions[reciever.id] = style;
			}

		 }
		 console.log("init ",$scope.flowStatus);
		  $timeout($scope.getStatus,10);
		
	}

	 $scope.locations =  $rootScope.locations;
	    for (var i = 0; i < $scope.locations.length; i++) {
			var location = $scope.locations[i];
			if (location.id==$scope.locationId){
				$scope.currentLocation = location;
				break;
			}
		}
		$timeout( $scope.flowStatus.init, 5000);
	   
	//     stateService.setAlert("הטיענה הצליחה, מתחיל בדיקה מצב דוחסים ופורסים");
	// repositoryService.getTopology().then(
	//   function(topology){
	//     $scope.locations =  topology;
	//     for (var i = 0; i < $scope.locations.length; i++) {
	// 		var location = $scope.locations[i];
	// 		if (location.id==$scope.locationId){
	// 			$scope.currentLocation = location;
	// 			break;
	// 		}
	// 	}
	// 	$timeout( $scope.flowStatus.init, 5000);
	   
	//     stateService.setAlert("הטיענה הצליחה, מתחיל בדיקה מצב דוחסים ופורסים");
  
	//   },
	//   function(rejected){
	//   	stateService.setAlert("בעיה בחיבור לשרת, בדוק חיבורים");
	//   },null);

	$scope.endFlow = function(recieverId,recieverName){
		var obj = new Object();
		obj["locationId"] = $scope.locationId;
		obj["recieverId"] = recieverId;
		topologyService.updateObject(obj,"endFlow",new function(){
                this.ok = function(datain){
                	console.log("flow ended ",recieverName);
                	stateService.setAlert(" שידור הפסיק : "+recieverName);
                }
                this.error = function(){
                	
                	alert("can't end flow"+recieverName);
                }});
	}

	$scope.showTrasmitters = function(locationId,rcvrId){

		var target = angular.element('#area_'+rcvrId);
		// console.log(target.prop("coords"),angular.element('#area_'+rcvrId));
		var coords = target.prop("coords");
		coords = coords.split(',')
		var rcvrInfo = angular.element('#rcvrInfo');

		
		$scope.currentRcvr = $scope.findRecvr(rcvrId);

		rcvrInfo.css("left",(parseInt(coords[0]))+"px");
		rcvrInfo.css("top",(parseInt(coords[1]))+"px");
		rcvrInfo.css("display","block");

		$scope.popoverTitle = $scope.currentRcvr.name;
		console.log("$scope.popoverTitle",$scope.popoverTitle);
		//alert("show controls")

	}

	$scope.openControlOfRCVR = function(){
		$('#remoteControl').modal('show');
	}
//--------
	$scope.initRemoteControlFlag = false;
	$scope.initRemoteControl = function initRemoteControl(){
		
		if ($scope.initRemoteControlFlag)
			return;

		$scope.initRemoteControlFlag = true;
		// Get all the keys from document
		var keys = document.querySelectorAll('#calculator span');
		var operators = ['HDMI', 'SVG','VGA','S-Video','RCA'];

		var ON_OFF =  ['ON', 'OFF'];
		var ON_OFF_title =  {ON:'Trun On', OFF:'Turn Off'};
		var operators_title = 'Set Input';
		var decimalAdded = false;

		console.log("extrat keys ",keys);
		// Add onclick event to all the keys and perform operations
		for(var i = 0; i < keys.length; i++) {
		  console.log("key",keys[i])
		  keys[i].onclick = function(e) {
		    // Get the input and button values
		    var input = document.querySelector('.screen');
		    var send_btn = document.querySelector('.send div');
		    var inputVal = input.innerHTML;
		    var btnVal = this.innerHTML;
		    
		    // Now, just append the key values (btnValue) to the input string and finally use javascript's eval function to get the result
		    // If clear key is pressed, erase everything

		    if(btnVal == 'RESET') {
		      input.innerHTML = '';
		      decimalAdded = false;
		    }
		    else if (ON_OFF.indexOf(inputVal)>-1  || ON_OFF.indexOf(btnVal)>-1){
		      input.innerHTML = btnVal;

		    } 
		    
		    
		    // Basic functionality of the calculator is complete. But there are some problems like 
		    // 1. No two operators should be added consecutively.
		    // 2. The equation shouldn't start from an operator except minus
		    // 3. not more than 1 decimal should be there in a number
		    
		    // We'll fix these issues using some simple checks
		    
		    // indexOf works only in IE9+
		    else if(operators.indexOf(btnVal) > -1) {
		      // Operator is clicked
		      // Get the last character from the equation
		      var lastChar = inputVal[inputVal.length - 1];
		      
		      // Only add operator if input is not empty and there is no operator at the last
		      if(inputVal != '' && operators.indexOf(lastChar) == -1) 
		        input.innerHTML += btnVal;
		      
		      // Allow minus if the string is empty
		      else if(inputVal == '' && btnVal == '-') 
		        input.innerHTML += btnVal;
		      
		      // Replace the last operator (if exists) with the newly pressed operator
		      if(operators.indexOf(btnVal) > -1 ) {
		        // Here, '.' matches any character while $ denotes the end of string, so anything (will be an operator in this case) at the end of string will get replaced by new operator
		        input.innerHTML = btnVal;
		      }
		      
		      decimalAdded =false;
		      // send_btn.innerHTML = operators_title;
		    }
		    
		    // Now only the decimal problem is left. We can solve it easily using a flag 'decimalAdded' which we'll set once the decimal is added and prevent more decimals to be added once it's set. It will be reset when an operator, eval or clear key is pressed.
		    else if(btnVal == '.') {
		      if(!decimalAdded) {
		        input.innerHTML += btnVal;
		        decimalAdded = true;
		      }
		    }
		    
		    // if any other key is pressed, just append it
		    else {
		      input.innerHTML += btnVal;
		    }
		    
		    // console.log(send_btn.innerHTML); 
		    // if (input.innerHTML==''){
		    //  send_btn.innerHTML = 'Select Option';
		    // }else if (ON_OFF_title[input.innerHTML]){
		    //  send_btn.innerHTML = ON_OFF_title[input.innerHTML];
		    // }
		    // else if (send_btn.innerHTML!=operators_title){
		    //  send_btn.innerHTML = "Set Channel";
		    // }
		    // prevent page jumps
		    e.preventDefault();
		  } 
		}

		};
		
	//-------
	$scope.openControl = function(transmiter){
		$scope.initRemoteControl();
		var typrOfObject = transmiter.reciever_type;
		if (transmiter.transmiter_type)
			 typrOfObject = transmiter.transmiter_type;
		$('#calculator').css('display','block');
		$('#calculator').toggleClass(typrOfObject);
		$('#remote_header').text(transmiter.name +'-'+typrOfObject);
		$('#remoteControl').modal('show');
	}
	$scope.manualHide = function(){
		var rcvrInfo = angular.element('#rcvrInfo');
		rcvrInfo.css("display","none");
	}
	$scope.startFlow = function(transmiter){
		console.log("start flow ",transmiter,$scope.currentRcvr);
		var flow = new Object();
		flow.transmiter = transmiter;
		flow.reciever = $scope.currentRcvr;
		topologyService.updateObject(flow,"startFlow",new function(){
                this.ok = function(datain){
                	console.log("flow started ",flow);
                	$scope.manualHide();
                	stateService.setAlert(" שידור התחיל : "+flow.transmiter.name+" ל "+flow.reciever.name);
                }
                this.error = function(){
                	$scope.manualHide();
                	alert("can't start flow");
                }});

	}
	$scope.findRecvr = function(rcvrId){
		for (var j = 0; j < $scope.currentLocation.recievers.length; j++) {
					
			if (rcvrId==$scope.currentLocation.recievers[j].id){
					console.log($scope.currentLocation.recievers[j].id,rcvrId,$scope.currentLocation.recievers[j].name);
					return $scope.currentLocation.recievers[j];
				}
			}
			
		
	}

	$scope.getStatus = function(){
		console.log("in getStatus");
		var obj = new Object();
		obj["locationId"]="1";
		$timeout($scope.getStatus, 1000);
		topologyService.updateObject(obj,"flowsStatus",new function(){
			this.ok = function(data){
				for (var member in $scope.flowStatus) 
					delete $scope.flowStatus[member];
				if (!data["flowStatus-array"][0].flowStatus)
					return;

				else if (data["flowStatus-array"][0].flowStatus.length){
					for (var i=0;i<data["flowStatus-array"][0].flowStatus.length;i++){
						var status = data["flowStatus-array"][0].flowStatus[i];
						console.log(status);
						$scope.flowStatus[status.recieverId] = status;

						status["position"] = $scope.flowStatusPositions[status.recieverId];
						if (status.recieverError || status.transmiterError)
							status["indicator"] = "icon-remove-sign";
						else 
							status["indicator"] = "icon-ok";

	
					
 						console.log(status);
					}
				}
				else if (data["flowStatus-array"][0].flowStatus){
					var status = data["flowStatus-array"][0].flowStatus;

					$scope.flowStatus[status.recieverId] = status;
					$scope.flowStatus[status.recieverId]["position"] = $scope.flowStatusPositions[status.recieverId];
					if (status.recieverError || status.transmiterError)
							status["indicator"] = "icon-remove-sign indicator-error";
						else 
							status["indicator"] = "icon-ok indicator-ok";
					console.log(status);
				}


			}
			this.error = function(){

			}
		})
	}
	
}