function usersCtrl($scope,userService,stateService,topologyService){

	 userService.getUsers().then(function(users){
         console.log("userService.getUsers()",users);
         $scope.users =   users;
         
      
       stateService.setAlert("רשימת המשתמשים נטענה"+users.length);
     
     },function(reason){
       console.log("userService.getUsers()",reason);

     },null);

  $scope.isActiveView = function(path){
  		
  		return path == "users"
 	}
  $scope.openedituser = function(useremail){
    $scope.edituserid = useremail;
  }
  $scope.closedituser = function(){
    $scope.edituserid = undefined  ;
  }
  $scope.createNewUser = function(){
     console.log("add new user")
     $scope.users.push(["NEW","","12345"] ) ;
     $scope.edituserid = "NEW"
  }
  $scope.deletetuser = function(user){
  var userId =  $scope.users.indexOf(user)
   var userObj = new Object();
  
   var userObj = new Object();
   userObj.locationId = 0;
   userObj.id = -1;
   userObj.objType = "user";
   userObj.email = user
 

 
    topologyService.updateObject(userObj,"delete",new function(){
                this.ok = function(data){
            }
            this.error = function(data){
               // alert("Fail to update user");
                  console.log(data,"delete ",userObj);
                   $scope.users[userId]=[userObj.email,userObj.filter]
                   window.location.reload(false); 

                }
         });     
  }
  
  $scope.changeUserType = function(userId){
      $scope.users[userId][2] = $("#usertype_"+userId).val()
  }
  
  $scope.updateOrCreateUSer = function(user){
    
   var userId =  $scope.users.indexOf(user)
   var userObj = new Object();
  
   var userObj = new Object();
   userObj.locationId = 0;
   userObj.objType = "user";
   userObj.email = $("#email_"+userId).val()
   userObj.password = $("#password_"+userId).val()
   userObj.filter = $("#filter_"+userId).val()
   userObj.type = $("#usertype_"+userId).val()
 
    topologyService.updateObject(userObj,"updateNew",new function(){
                this.ok = function(data){
            }
            this.error = function(data){
              
                  console.log(data,"updateNew ",userObj);
                   $scope.users[userId]=[userObj.email,userObj.filter]
                   window.location.reload(false); 

                }
         });     
  }
}